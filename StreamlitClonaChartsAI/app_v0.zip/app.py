import streamlit as st
from google import genai
from google.genai import types
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import json
import re
import traceback
from PIL import Image
import io
import base64
from code_editor import code_editor

# ─── Page Config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Chart Vision · AI Analyzer",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Custom CSS ─────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Mono:ital,wght@0,300;0,400;0,500;1,300&family=Syne:wght@400;600;700;800&display=swap');

/* Base Reset */
html, body, [class*="css"] {
    font-family: 'Syne', sans-serif;
}

.stApp {
    background: #f8f9fa;
    color: #212529;
}

/* Hide default elements */
#MainMenu, footer, header { visibility: hidden; }
.block-container { padding-top: 2rem; padding-bottom: 2rem; }

/* ── Hero Header ── */
.hero {
    text-align: center;
    padding: 3rem 1rem 2rem;
    position: relative;
}
.hero-badge {
    display: inline-block;
    font-family: 'DM Mono', monospace;
    font-size: 0.7rem;
    letter-spacing: 0.25em;
    text-transform: uppercase;
    color: #2962ff;
    background: rgba(41,98,255,0.1);
    border: 1px solid rgba(41,98,255,0.3);
    padding: 0.3rem 1rem;
    border-radius: 100px;
    margin-bottom: 1.5rem;
}
.hero h1 {
    font-size: clamp(2.5rem, 6vw, 4rem);
    font-weight: 800;
    line-height: 1.05;
    margin: 0 0 1rem;
    background: linear-gradient(135deg, #1a237e 0%, #2962ff 50%, #448aff 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}
.hero p {
    font-size: 1.1rem;
    color: #495057;
    max-width: 520px;
    margin: 0 auto;
    line-height: 1.6;
}

/* ── Step Cards ── */
.step-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1px;
    background: rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
    border-radius: 16px;
    overflow: hidden;
    margin: 2rem 0;
}
.step-card {
    background: #ffffff;
    padding: 1.5rem;
    position: relative;
}
.step-num {
    font-family: 'DM Mono', monospace;
    font-size: 0.65rem;
    letter-spacing: 0.2em;
    color: #2962ff;
    margin-bottom: 0.5rem;
}
.step-title {
    font-size: 0.9rem;
    font-weight: 700;
    color: #212529;
    margin-bottom: 0.3rem;
}
.step-desc {
    font-size: 0.75rem;
    color: #6c757d;
    line-height: 1.5;
}

/* ── Upload Zone ── */
.upload-zone {
    border: 1.5px dashed rgba(41,98,255,0.4);
    border-radius: 16px;
    background: rgba(41,98,255,0.02);
    padding: 2.5rem;
    text-align: center;
    transition: all 0.3s ease;
}
.upload-zone:hover {
    border-color: rgba(41,98,255,0.7);
    background: rgba(41,98,255,0.05);
}

/* ── Section Labels ── */
.section-label {
    font-family: 'DM Mono', monospace;
    font-size: 0.65rem;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    color: #2962ff;
    margin-bottom: 0.75rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}
.section-label::after {
    content: '';
    flex: 1;
    height: 1px;
    background: rgba(41,98,255,0.2);
}

/* ── Analysis Card ── */
.analysis-card {
    background: linear-gradient(135deg, rgba(41,98,255,0.05), rgba(68,138,255,0.02));
    border: 1px solid rgba(41,98,255,0.15);
    border-radius: 16px;
    padding: 1.5rem;
    margin: 1rem 0;
}
.chart-type-badge {
    display: inline-block;
    background: linear-gradient(135deg, #2962ff, #448aff);
    color: white;
    font-family: 'DM Mono', monospace;
    font-size: 0.7rem;
    font-weight: 500;
    letter-spacing: 0.1em;
    padding: 0.3rem 0.9rem;
    border-radius: 100px;
    margin-bottom: 0.75rem;
}

/* ── Code Block ── */
.code-wrapper {
    background: #f1f3f5;
    border: 1px solid rgba(41,98,255,0.15);
    border-radius: 12px;
    overflow: hidden;
    font-family: 'DM Mono', monospace;
}
.code-header {
    background: rgba(41,98,255,0.05);
    border-bottom: 1px solid rgba(41,98,255,0.1);
    padding: 0.6rem 1rem;
    font-size: 0.7rem;
    letter-spacing: 0.1em;
    color: #2962ff;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.code-dots { display: flex; gap: 5px; }
.code-dot {
    width: 10px; height: 10px;
    border-radius: 50%;
}

/* ── Divider ── */
.section-divider {
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(41,98,255,0.2), transparent);
    margin: 2.5rem 0;
}

/* ── Status Pills ── */
.status-pill {
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    padding: 0.3rem 0.8rem;
    border-radius: 100px;
    font-family: 'DM Mono', monospace;
    font-size: 0.7rem;
}
.status-success {
    background: rgba(25,135,84,0.1);
    border: 1px solid rgba(25,135,84,0.2);
    color: #198754;
}
.status-error {
    background: rgba(220,53,69,0.1);
    border: 1px solid rgba(220,53,69,0.2);
    color: #dc3545;
}
.status-info {
    background: rgba(41,98,255,0.1);
    border: 1px solid rgba(41,98,255,0.2);
    color: #0d6efd;
}

/* ── Streamlit Component Overrides ── */
.stButton > button {
    background: linear-gradient(135deg, #2962ff 0%, #1565c0 100%);
    color: white;
    border: none;
    border-radius: 10px;
    font-family: 'Syne', sans-serif;
    font-weight: 600;
    font-size: 0.9rem;
    padding: 0.65rem 1.5rem;
    width: 100%;
    transition: all 0.2s ease;
    letter-spacing: 0.02em;
}
.stButton > button:hover {
    background: linear-gradient(135deg, #448aff 0%, #2962ff 100%);
    box-shadow: 0 4px 12px rgba(41,98,255,0.2);
    transform: translateY(-1px);
}
.stButton > button:active {
    transform: translateY(0);
}

div[data-testid="stDataEditor"] {
    border: 1px solid rgba(41,98,255,0.15) !important;
    border-radius: 12px !important;
    overflow: hidden !important;
    background: white !important;
}

.stTextArea textarea {
    background: white !important;
    border: 1px solid rgba(41,98,255,0.15) !important;
    border-radius: 10px !important;
    font-family: 'DM Mono', monospace !important;
    font-size: 0.82rem !important;
    color: #212529 !important;
    resize: vertical !important;
}
.stTextArea textarea:focus {
    border-color: rgba(41,98,255,0.5) !important;
    box-shadow: 0 0 0 2px rgba(41,98,255,0.1) !important;
}

.stSelectbox > div > div {
    background: white !important;
    border: 1px solid rgba(41,98,255,0.15) !important;
    border-radius: 10px !important;
    color: #212529 !important;
}

.stFileUploader > div {
    background: rgba(41,98,255,0.02) !important;
    border: 1.5px dashed rgba(41,98,255,0.3) !important;
    border-radius: 16px !important;
}

div[data-testid="stAlert"] {
    border-radius: 12px !important;
}

/* Info boxes */
.stInfo {
    background: rgba(41,98,255,0.05) !important;
    border: 1px solid rgba(41,98,255,0.15) !important;
    border-radius: 12px !important;
}

.sidebar-content {
    padding: 1.5rem 1rem;
}
</style>
""", unsafe_allow_html=True)


# ─── Sidebar Configuration ──────────────────────────────────────────────────────
@st.cache_data(show_spinner="Obteniendo modelos...")
def fetch_available_models(api_key: str):
    """Fetch available models from Gemini API."""

    client = genai.Client(api_key=api_key)
    models = []
    for model in client.models.list():
        # Filter models that support content generation                    
        if "gemini" in model.name:            
            # Remove 'models/' prefix if present
            name = model.name.replace("models/", "")
            models.append(name)
        
    print("Modelos")                
    print(models)                
    return sorted(models)


with st.sidebar:
    st.markdown("""
    <div style="padding: 1rem 0; text-align: center;">
        <span style="font-size: 3rem;">📊</span>
        <h2 style="margin: 0.5rem 0; font-size: 1.2rem;">Chart Vision</h2>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("---")
    st.markdown("""
    <div style="font-size: 0.8rem; color: #6c757d;">
        <p><b>Chart Vision v1.1</b></p>
        <p>Analizador de gráficas inteligente con Google Gemini.</p>
    </div>
    """, unsafe_allow_html=True)


# ─── Gemini Setup ───────────────────────────────────────────────────────────────
# Get API Key early for model loading
api_key = st.secrets.get("GEMINI_API_KEY", "")
if not api_key:
    st.error("⚠️ Configura `GEMINI_API_KEY` en los Secrets de Streamlit.")
    st.stop()
st.session_state.gemini_api_key = api_key

def get_gemini_client() -> genai.Client:
    """Return an authenticated google-genai Client (new SDK ≥ 1.0)."""
    api_key = st.session_state.gemini_api_key
    if not api_key:
        st.error("⚠️ Por favor, introduce tu `GEMINI_API_KEY` en la barra lateral.")
        st.stop()
    return genai.Client(api_key=api_key)


def _image_part(img_bytes: bytes) -> types.Part:
    """Convert raw image bytes to a google-genai Part."""
    # Detect mime type from magic bytes
    if img_bytes[:4] == b'\x89PNG':
        mime = "image/png"
    elif img_bytes[:2] in (b'\xff\xd8',):
        mime = "image/jpeg"
    elif img_bytes[:4] == b'RIFF':
        mime = "image/webp"
    else:
        mime = "image/png"  # fallback

    return types.Part.from_bytes(data=img_bytes, mime_type=mime)


# ─── Helpers ────────────────────────────────────────────────────────────────────
def extract_json(text: str) -> dict:
    """Extract the first JSON object found in a string."""
    match = re.search(r'\{[\s\S]*\}', text)
    if not match:
        raise ValueError("No se encontró JSON en la respuesta.")
    return json.loads(match.group())


def extract_code(text: str) -> str:
    """Extract Python code from markdown code blocks."""
    match = re.search(r'```(?:python)?\n([\s\S]*?)```', text)
    if match:
        return match.group(1).strip()
    return text.strip()


ANALYSIS_PROMPT = """
Analiza esta imagen de una gráfica/chart con detalle y responde ÚNICAMENTE con un objeto JSON válido (sin texto extra, sin markdown).

El JSON debe tener exactamente esta estructura:
{
  "chart_type": "tipo de gráfica en inglés (bar, line, scatter, pie, area, histogram, heatmap, box, funnel, treemap, etc.)",
  "title": "título de la gráfica si es visible, o vacío",
  "x_label": "etiqueta del eje X si aplica, o vacío",
  "y_label": "etiqueta del eje Y si aplica, o vacío",
  "description": "descripción breve de qué muestra la gráfica",
  "columns": [
    {"name": "NombreColumna1", "type": "category|number|date", "description": "qué representa"}
  ],
  "sample_data": [
    {"NombreColumna1": valor1, "NombreColumna2": valor2}
  ],
  "color_scheme": "descripción del esquema de colores usado",
  "series": ["nombre de series si hay múltiples, o vacío"]
}

Extrae los datos reales visibles en la gráfica para sample_data (mínimo 5 filas si es posible).
Las columnas deben reflejar exactamente qué datos necesita la gráfica para reproducirse.
"""

CODE_PROMPT_TEMPLATE = """
Basándote en esta imagen de una gráfica, genera código Python con Plotly que la reproduzca lo más fielmente posible.

Información detectada:
- Tipo: {chart_type}
- Título: {title}
- Eje X: {x_label}
- Eje Y: {y_label}
- Descripción: {description}
- Esquema de colores: {color_scheme}

El código debe:
1. Usar pandas para los datos (variable `df` ya estará disponible con los datos del usuario)
2. Usar plotly.express o plotly.graph_objects según sea más apropiado
3. Reproducir colores, estilos y formato lo más cercano posible a la imagen original
4. Asignar el resultado final a una variable llamada `fig`
5. NO llamar fig.show() al final
6. Incluir comentarios explicativos en cada sección del código
7. Aplicar layout personalizado (títulos, ejes, colores de fondo, fuentes)

IMPORTANTE: Responde SOLO con el bloque de código Python entre ```python y ```, sin explicaciones adicionales.
El código debe asumir que `df` (un DataFrame de pandas) ya existe con las columnas apropiadas.
"""


def analyze_image(client: genai.Client, img_bytes: bytes) -> dict:
    """Send image to Gemini and parse analysis JSON (new google-genai SDK)."""
    response = client.models.generate_content(
        model=st.session_state.selected_model,
        contents=[
            types.Content(parts=[
                _image_part(img_bytes),
                types.Part.from_text(text=ANALYSIS_PROMPT),
            ])
        ],
    )
    return extract_json(response.text)


def generate_code(client: genai.Client, img_bytes: bytes, analysis: dict) -> str:
    """Ask Gemini to generate Plotly code for the chart (new google-genai SDK)."""
    prompt = CODE_PROMPT_TEMPLATE.format(
        chart_type=analysis.get("chart_type", ""),
        title=analysis.get("title", ""),
        x_label=analysis.get("x_label", ""),
        y_label=analysis.get("y_label", ""),
        description=analysis.get("description", ""),
        color_scheme=analysis.get("color_scheme", ""),
    )
    response = client.models.generate_content(
        model=st.session_state.selected_model,
        contents=[
            types.Content(parts=[
                _image_part(img_bytes),
                types.Part.from_text(text=prompt),
            ])
        ],
    )
    return extract_code(response.text)


def build_default_df(analysis: dict) -> pd.DataFrame:
    """Build a DataFrame from analysis sample_data and columns."""
    columns = analysis.get("columns", [])
    sample = analysis.get("sample_data", [])

    if sample:
        df = pd.DataFrame(sample)
        # Cast types
        for col_info in columns:
            cname = col_info.get("name", "")
            ctype = col_info.get("type", "category")
            if cname in df.columns:
                try:
                    if ctype == "number":
                        df[cname] = pd.to_numeric(df[cname], errors="coerce")
                    elif ctype == "date":
                        df[cname] = pd.to_datetime(df[cname], errors="coerce")
                except Exception:
                    pass
        return df

    # Fallback empty DataFrame with declared columns
    if columns:
        return pd.DataFrame({c["name"]: [] for c in columns})
    return pd.DataFrame({"X": [], "Y": []})


# ─── UI ─────────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="hero">
    <div class="hero-badge">✦ Powered by Google Gemini</div>
    <h1>Chart Vision</h1>
    <p>Sube una imagen de cualquier gráfica y la IA la analizará, extraerá sus datos y generará código Plotly para reproducirla.</p>
</div>
""", unsafe_allow_html=True)

# Step indicators
st.markdown("""
<div class="step-grid">
    <div class="step-card">
        <div class="step-num">01 ─ UPLOAD</div>
        <div class="step-title">Cargar Imagen</div>
        <div class="step-desc">Sube cualquier tipo de gráfica en PNG, JPG o WEBP</div>
    </div>
    <div class="step-card">
        <div class="step-num">02 ─ ANALYZE</div>
        <div class="step-title">Análisis con IA</div>
        <div class="step-desc">Gemini detecta el tipo y extrae los datos visibles</div>
    </div>
    <div class="step-card">
        <div class="step-num">03 ─ EDIT</div>
        <div class="step-title">Editar Datos</div>
        <div class="step-desc">Ajusta o completa los datos en el editor interactivo</div>
    </div>
    <div class="step-card">
        <div class="step-num">04 ─ RENDER</div>
        <div class="step-title">Generar Gráfica</div>
        <div class="step-desc">Ejecuta el código y visualiza el resultado en Plotly</div>
    </div>
</div>
""", unsafe_allow_html=True)

st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)

# ─── Step 1: Upload ──────────────────────────────────────────────────────────────
st.markdown('<div class="section-label">01 · Imagen de la Gráfica</div>', unsafe_allow_html=True)

uploaded_file = st.file_uploader(
    "Arrastra o selecciona una imagen",
    type=["png", "jpg", "jpeg", "webp"],
    label_visibility="collapsed",
)

if uploaded_file:
    img_bytes = uploaded_file.read()

    col_img, col_info = st.columns([1, 1], gap="large")
    with col_img:
        st.image(img_bytes, caption="Imagen cargada", use_container_width=True)
    with col_info:
        st.markdown("""
        <div class="analysis-card">
            <div class="status-pill status-success">✓ Imagen lista para analizar</div>
            <br/>
            <p style="color:#495057; font-size:0.85rem; line-height:1.7; margin:0">
                La imagen será enviada a Google Gemini para:<br/>
                · Detectar el tipo de gráfica<br/>
                · Identificar ejes y etiquetas<br/>
                · Extraer datos visibles<br/>
                · Generar código Plotly personalizado
            </p>
        </div>
        """, unsafe_allow_html=True)

        # Dynamic Model Loading in Main UI
        model_options = fetch_available_models(st.session_state.gemini_api_key)
        if not model_options:
            model_options = ["gemini-1.5-flash", "gemini-1.5-pro", "gemini-2.0-flash-exp"]
        
        default_model = "gemini-1.5-flash"
        if "selected_model" in st.session_state and st.session_state.selected_model in model_options:
            default_index = model_options.index(st.session_state.selected_model)
        elif default_model in model_options:
            default_index = model_options.index(default_model)
        else:
            default_index = 0

        selected_model = st.selectbox(
            "Selecciona el modelo de IA",
            options=model_options,
            index=default_index,
            help="Elige el modelo que procesará tu imagen",
            key="model_selector_main"
        )
        st.session_state.selected_model = selected_model

        analyze_btn = st.button("🔍 Analizar con Gemini", use_container_width=True)

    # ─── Step 2: Analysis ─────────────────────────────────────────────────────────
    if analyze_btn or "analysis" in st.session_state:

        if analyze_btn:
            client = get_gemini_client()
            with st.spinner("Gemini está analizando tu gráfica…"):
                try:
                    st.session_state.analysis = analyze_image(client, img_bytes)
                    st.session_state.img_bytes = img_bytes
                    # Reset downstream state
                    if "generated_code" in st.session_state:
                        del st.session_state.generated_code
                except Exception as e:
                    st.error(f"Error al analizar: {e}")
                    st.stop()

        analysis = st.session_state.analysis
        img_bytes = st.session_state.img_bytes

        st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
        st.markdown('<div class="section-label">02 · Resultado del Análisis</div>', unsafe_allow_html=True)

        chart_type = analysis.get("chart_type", "unknown")
        chart_title = analysis.get("title", "Sin título detectado")
        description = analysis.get("description", "")

        st.markdown(f"""
        <div class="analysis-card">
            <div class="chart-type-badge">📊 {chart_type.upper()}</div>
            <h4 style="color:#212529; margin:0 0 0.5rem; font-size:1rem">{chart_title}</h4>
            <p style="color:#495057; font-size:0.85rem; margin:0 0 1rem">{description}</p>
            <div style="display:flex; gap:1rem; flex-wrap:wrap">
                <span style="font-family:'DM Mono',monospace; font-size:0.72rem; color:#6c757d">
                    Eje X · <span style="color:#2962ff">{analysis.get('x_label','—')}</span>
                </span>
                <span style="font-family:'DM Mono',monospace; font-size:0.72rem; color:#6c757d">
                    Eje Y · <span style="color:#2962ff">{analysis.get('y_label','—')}</span>
                </span>
                <span style="font-family:'DM Mono',monospace; font-size:0.72rem; color:#6c757d">
                    Colores · <span style="color:#2962ff">{analysis.get('color_scheme','—')}</span>
                </span>
            </div>
        </div>
        """, unsafe_allow_html=True)

        # ─── Step 3: Data Editor ───────────────────────────────────────────────────
        st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
        st.markdown('<div class="section-label">03 · Editor de Datos</div>', unsafe_allow_html=True)
        st.markdown(
            '<p style="color:#495057; font-size:0.85rem; margin-bottom:1rem">'
            'Los datos fueron extraídos automáticamente de la imagen. '
            'Puedes editarlos, agregar filas o corregir valores antes de generar la gráfica.</p>',
            unsafe_allow_html=True
        )

        if "df_edited" not in st.session_state or analyze_btn:
            st.session_state.df_edited = build_default_df(analysis)

        # Column config based on detected types
        col_config = {}
        for col_info in analysis.get("columns", []):
            cname = col_info.get("name", "")
            ctype = col_info.get("type", "category")
            cdesc = col_info.get("description", "")
            if ctype == "number":
                col_config[cname] = st.column_config.NumberColumn(
                    cname, help=cdesc, format="%.2f"
                )
            elif ctype == "date":
                col_config[cname] = st.column_config.DateColumn(cname, help=cdesc)
            else:
                col_config[cname] = st.column_config.TextColumn(cname, help=cdesc)

        edited_df = st.data_editor(
            st.session_state.df_edited,
            column_config=col_config if col_config else None,
            num_rows="dynamic",
            use_container_width=True,
            key="data_editor_main",
        )
        st.session_state.df_edited = edited_df

        st.markdown(f"""
        <div style="margin-top:0.5rem">
            <span class="status-pill status-info">📋 {len(edited_df)} filas · {len(edited_df.columns)} columnas</span>
        </div>
        """, unsafe_allow_html=True)

        # ─── Generate Code Button ─────────────────────────────────────────────────
        st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
        st.markdown('<div class="section-label">04 · Código Generado</div>', unsafe_allow_html=True)

        col_gen, col_regen = st.columns([2, 1])
        with col_gen:
            gen_btn = st.button("⚡ Generar Código Plotly", use_container_width=True)
        with col_regen:
            if "generated_code" in st.session_state:
                regen_btn = st.button("🔄 Regenerar Código", use_container_width=True)
            else:
                regen_btn = False

        if gen_btn or regen_btn:
            client = get_gemini_client()
            with st.spinner("Generando código Plotly personalizado…"):
                try:
                    code = generate_code(client, img_bytes, analysis)
                    st.session_state.generated_code = code
                except Exception as e:
                    st.error(f"Error al generar código: {e}")

        if "generated_code" in st.session_state:
            raw_code = st.session_state.generated_code

            # Code display with syntax highlighting via st.code
            st.markdown("""
            <div class="code-wrapper">
                <div class="code-header">
                    <div class="code-dots">
                        <div class="code-dot" style="background:#ff5f57"></div>
                        <div class="code-dot" style="background:#ffbd2e"></div>
                        <div class="code-dot" style="background:#28ca41"></div>
                    </div>
                    <span>plotly_chart.py</span>
                    <span style="color:#6c757d">Python · Plotly</span>
                </div>
            </div>
            """, unsafe_allow_html=True)

            # Editable code area
            edited_code = st.text_area(
                "Código editable:",
                value=raw_code,
                height=420,
                label_visibility="collapsed",
                key="code_editor",
            )


            # Create the editor
            response = code_editor(
                raw_code,
                lang="python",
                theme="vs-dark",
                response_mode='blur',
                height=[10, 20] # Min and max lines
                
            )
            
            st.code(response)
            st.session_state.generated_code = edited_code

            st.markdown("""
            <p style="color:#6c757d; font-size:0.78rem; margin-top:0.4rem; font-family:'DM Mono',monospace">
            ↑ Puedes editar el código directamente antes de ejecutarlo
            </p>
            """, unsafe_allow_html=True)

            # ─── Execute & Render ──────────────────────────────────────────────────
            st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
            st.markdown('<div class="section-label">05 · Gráfica Generada</div>', unsafe_allow_html=True)

            run_btn = st.button("▶ Ejecutar y Mostrar Gráfica", use_container_width=True)

            if run_btn:
                df = edited_df.copy()
                local_vars = {"df": df, "px": px, "go": go, "pd": pd}
                try:
                    exec(edited_code, local_vars)
                    fig = local_vars.get("fig")
                    if fig is None:
                        st.error("El código no asignó ninguna figura a la variable `fig`.")
                    else:
                        st.markdown(
                            '<div class="status-pill status-success" style="margin-bottom:1rem">✓ Código ejecutado correctamente</div>',
                            unsafe_allow_html=True,
                        )
                        st.plotly_chart(fig, use_container_width=True)

                        # Comparison columns
                        st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
                        st.markdown('<div class="section-label">Comparación</div>', unsafe_allow_html=True)
                        c1, c2 = st.columns(2)
                        with c1:
                            st.markdown("**Original**")
                            st.image(img_bytes, use_container_width=True)
                        with c2:
                            st.markdown("**Reproducida con Plotly**")
                            st.plotly_chart(fig, use_container_width=True, key="compare_fig")

                except Exception as e:
                    st.markdown(
                        f'<div class="status-pill status-error">✗ Error de ejecución</div>',
                        unsafe_allow_html=True,
                    )
                    st.error(f"**Error:** {e}")
                    with st.expander("Ver traceback completo"):
                        st.code(traceback.format_exc(), language="python")

else:
    # Empty state
    st.markdown("""
    <div style="text-align:center; padding:4rem 2rem; color:#3d3d52">
        <div style="font-size:4rem; margin-bottom:1rem">📈</div>
        <div style="font-family:'DM Mono',monospace; font-size:0.8rem; letter-spacing:0.15em">
            ESPERANDO IMAGEN · SUBE UNA GRÁFICA PARA COMENZAR
        </div>
    </div>
    """, unsafe_allow_html=True)